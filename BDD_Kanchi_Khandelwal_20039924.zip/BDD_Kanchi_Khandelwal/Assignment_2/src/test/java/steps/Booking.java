package steps;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Booking {
	public static WebDriver driver;
	public static JavascriptExecutor js = (JavascriptExecutor) driver;
	public static int i;
	public static WebDriverWait wait;
	public static String From , To , ArrDate,DeptDate ;
	public static int Fare , travellers ;
	
	@Before(value = "@search")
	public void OpenBrowser() {
		  WebDriverManager.chromedriver().setup();
		  driver = new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
		  wait = new WebDriverWait(driver , 100);
	}

	@After(value = "@Book")
	public void CloseBrowser(Scenario scenario) {
		driver.quit();
	}

	
	@Given("Launch of GoIbibo Website")
	public void launch_of_GoIbibo_Website() {
	   
	    driver.get("https://www.goibibo.com/");
	}


	@When("^user select travel option as \"([^\"]*)\"$")
	public void user_select_travel_option_as(String way) {
	   if(way.equals("OneWay"))
	   {
		   i=1;
		   driver.findElement(By.xpath("//*[@id=\"oneway\"]")).click();
	   }
	   else if(way.equals("RoundTrip"))
	   {
		   i=2;
		   driver.findElement(By.xpath("//*[@id=\"roundTrip\"]")).click();
	   }
	   else
	   {
		   i=3;
		   driver.findElement(By.xpath("//*[@id=\"multiCity\"]")).click();
	   }
	   System.out.println(i);
	}

	@Then("^user select from place as \"([^\"]*)\"$")
	public void user_select_from_place_as(String departure) {
		WebElement depart;
	System.out.println(departure);
	if(i==3)
	{
		depart = 	driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/input"));
		depart.sendKeys(departure);
		driver.findElement(By.xpath("//*[@id=\"react-autosuggest-1-suggestion--0\"]")).click();
	}
	else
	{
	 depart = driver.findElement(By.xpath("//*[@id=\"gosuggest_inputSrc\"]"));
	depart.sendKeys(departure);
	driver.findElement(By.xpath("//*[@id=\"react-autosuggest-1-suggestion--0\"]")).click();
	}
	From = departure;
	}

	@Then("^user select \"([^\"]*)\"$ destination if multiway$")
	public void user_select_destination_if_multiway(String mid) {
		System.out.println("mid:"+i);
		if(i==3)
		{	
			driver.findElement(By.cssSelector("/html/body/div[1]/div/div[2]/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[3]/input")).sendKeys(mid);
			driver.findElement(By.xpath("//*[@id=\"react-autosuggest-1-suggestion--0\"]")).click();
		}
	    }

	@Then("^user select to place as \"([^\"]*)\"$")
	public void user_select_to_place_as(String arr) {
		WebElement arrival;
		if(i==3)
		{
			arrival = driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/input"));
			arrival.sendKeys(arr);
			driver.findElement(By.xpath("//*[@id=\"react-autosuggest-1-suggestion--0\"]")).click();
		}
		else
		{
		arrival = driver.findElement(By.xpath("//*[@id=\"gosuggest_inputDest\"]"));
		arrival.sendKeys(arr);
		driver.findElement(By.xpath("//*[@id=\"react-autosuggest-1-suggestion--0\"]")).click();
		}
		To = arr;
	}

	@Then("user select to departure date as \"([^\"]*)\" and \"([^\"]*)\"$" )
	public void user_select_to_departure_date_as(String date1, String date2) throws InterruptedException {	  
		
		
		switch(i)
		{
		case 1:
			driver.findElement(By.xpath("//*[@id=\"searchWidgetCommon\"]/div[1]/div[1]/div[1]/div[1]/div[5]/div/div/div[1]/span")).click();
			driver.findElement(By.xpath("//*[@aria-label = '"+date1+"']")).click(); 
			
			break;
		case 2:
			driver.findElement(By.xpath("//*[@id=\"searchWidgetCommon\"]/div[1]/div[1]/div[1]/div[1]/div[5]/div/div/div[1]/span")).click();
			driver.findElement(By.xpath("//*[@aria-label = '"+date1+"']")).click(); 
			
			driver.findElement(By.xpath("//*[@aria-label = '"+date2+"']")).click(); 
			
			break;
		case 3:
			driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[5]/input")).click();
			driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[5]/div/div/div[1]/span[2]")).click();
			driver.findElement(By.xpath("//*[@aria-label = '"+date1+"']")).click(); 	
			Thread.sleep(1000);
			driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[5]/input")).click();
			driver.findElement(By.xpath("//*[@aria-label = '"+date2+"']")).click(); 
		}
		
		DeptDate = date1;
		ArrDate = date2;
	}

	@Then("user select to number of travellers as {string} and travel class as {string}")
	public void user_select_to_number_of_travellers_as_and_travel_class_as(String traveller, String Class) {
	   
		driver.findElement(By.xpath("//*[@id=\"pax_link_common\"]")).click();
		int num = Integer.parseInt(traveller);
		travellers = num;
		while(num > 1)
		{
			driver.findElement(By.xpath("//*[@id=\"adultPaxPlus\"]")).click();
			num--;
		}
	    
		new Select(driver.findElement(By.xpath("//*[@id=\"gi_class\"]"))).selectByVisibleText(Class);
	}

	@Then("the flights are search successfully")
	public void the_flights_are_search_successfully() {
	   
		driver.findElement(By.xpath("//*[@id=\"gi_search_btn\"]")).click();
	   
	}

@When("User select the lowest price of flight and book")
public void user_select_the_lowest_price_of_flight_and_book() {
	String fare=null;
	int p;	
	switch(i)
	{
	case 1:
		fare = driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/div[2]/div[2]/div[2]/div[2]/div[2]/div[1]/div/div/div[1]/div[2]/div/span/span[2]/span")).getText();
		p = fare.indexOf(",");
		fare = 	fare.substring(0, p) + fare.substring(p + 1);
		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/div[2]/div[2]/div[2]/div[2]/div[2]/div[1]/div/div/div[1]/div[2]/span/span")).click();
		break;
	case 2:
		fare=driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/div[2]/div[2]/div[2]/div[2]/div[1]/div/div[2]/span[1]/span[1]/span")).getText();
		p = fare.indexOf(",");
		fare = 	fare.substring(0, p) + fare.substring(p + 1);
		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/div[2]/div[2]/div[2]/div[2]/div[1]/div/div[2]/span[2]/span/input")).click();
		break;
	case 3:
		fare = "3";
		
	}
	Fare =  Integer.parseInt(fare) * travellers;
}


@Then("The Flight selected details are reviewed.")
public void the_Flight_selected_details_are_reviewed() throws InterruptedException {
		/*
		 * String desc = driver.findElement(By.xpath(
		 * "//*[@id=\"content\"]/div/div/div/div[2]/div/div[1]/div[1]/div[2]/div/div/div[1]/span[1]"
		 * )).getText(); String m1 = driver.findElement(By.xpath(
		 * "//*[@id=\"fareSummary\"]/div[1]/div[1]/div[2]/div[1]/div[2]/span[1]/span")).
		 * getText(); int p = m1.indexOf(","); m1 = m1.substring(0, p) + m1.substring(p
		 * + 1); p = DeptDate.indexOf(" "); DeptDate = DeptDate.substring(p+1,p+4);
		 * System.out.println(DeptDate); boolean value = desc.contains(From);
		 * Assert.assertTrue("incorrect departure", value); value = desc.contains(To);
		 * Assert.assertTrue("incorrect arrival", value); value = Integer.parseInt(m1)
		 * == Fare; Assert.assertTrue("incorrect fare", value); value =
		 * desc.contains(DeptDate); Assert.assertTrue("incorrect date", value);
		 */
}
	}
