package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@CucumberOptions(stepNotifications = true,
  				 features = "src/test/java/features", 
  				 glue = "steps", monochrome = true, 
  				 tags = "@Gillete" ,
  				 plugin = {"pretty" , "html:target/cucumber"})
@RunWith(Cucumber.class)

public class RunCuke {

}
