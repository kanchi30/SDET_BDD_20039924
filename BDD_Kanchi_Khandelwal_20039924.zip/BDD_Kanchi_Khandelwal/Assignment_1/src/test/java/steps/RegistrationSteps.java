package steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class RegistrationSteps {
	public static WebDriver driver;
	public static JavascriptExecutor js = (JavascriptExecutor) driver;
	public static int i;

	@Before()
	public void OpenBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	}

	@After
	public void CloseBrowser(Scenario scenario) {
		 driver.quit();
	}

	@Given("^User navigates to Gillete Website as \"([^\"]*)\"$")
	public void user_navigates_to_Gillete_Website(String URL) {
		driver.get(URL);
		if (URL.equals("https://www.gillette.co.in/en-in"))
			i = 1;
		else if (URL.equals("https://www.gillette.de/"))
			i = 2;
		else
			i = 3;
	}

	@When("the user navigates to registration page")
	public void the_user_navigates_to_registration_page() {
		switch (i) {
		case 1:
			driver.findElement(By.className("event_profile_register")).click();
			break;
		case 2:
			new Actions(driver)
					.moveToElement(driver.findElement(By.xpath("//*[@id=\"nav\"]/div[2]/div[2]/div[2]/div/div[1]")))
					.perform();
			driver.findElement(By.xpath("//*[@id=\"nav\"]/div[2]/div[2]/div[2]/div/div[1]/div/nav/ul/li[2]")).click();
			break;
		case 3:
			driver.findElement(By.xpath("//*[@id=\"user_link\"]/li[1]/a")).click();
		}

		System.out.println(driver.getTitle());

	}

	@Then("^the user enter first name as \"([^\"]*)\"$")
	public void the_user_enter_first_name_as(String firstName) {
		switch (i) {
		case 1:
			driver.findElement(By.id("phdesktopbody_0_grs_consumer[firstname]")).sendKeys(firstName);
			break;
		case 2:
			driver.findElement(By.xpath("//*[@id=\"customerName\"]")).sendKeys(firstName);
			break;
		case 3:
			driver.findElement(By.xpath("//*[@id=\"SubmitCreate\"]")).click();
			driver.findElement(By.xpath("//*[@id=\"customer_firstname\"]")).sendKeys(firstName);
		}
	}

	@Then("^the user enter last name as \"([^\"]*)\"$")
	public void the_user_enter_last_name_as(String lastName) {
		switch (i) {
		case 1:
			driver.findElement(By.id("phdesktopbody_0_grs_consumer[lastname]")).sendKeys(lastName);
			break;
		case 3:
			driver.findElement(By.xpath("//*[@id=\"customer_lastname\"]")).sendKeys(lastName);
		}

	}

	@Then("^the user enter email as \"([^\"]*)\"$")
	public void the_user_enter_email_as(String email) {
		switch (i) {
		case 1:
			driver.findElement(By.id("phdesktopbody_0_grs_account[emails][0][address]")).sendKeys(email);
			break;
		case 2:
			driver.findElement(By.xpath("//*[@id=\"customerEmail\"]")).sendKeys(email);
			driver.findElement(By.xpath("//*[@id=\"confirmCustomerEmail\"]")).sendKeys(email);
			break;
		case 3:
			driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(email);
		}
	}

	@Then("^the user enter password as \"([^\"]*)\"$")
	public void the_user_enter_password_as(String password) {
		switch (i) {
		case 1:
			driver.findElement(By.id("phdesktopbody_0_grs_account[password][password]")).sendKeys(password);
			break;
		case 2:
			driver.findElement(By.xpath("//*[@id=\"customerPassword\"]")).sendKeys(password);
			break;
		case 3:
			driver.findElement(By.xpath("//*[@id=\"passwd\"]")).sendKeys(password);
		}
	}

	@Then("^the user enter confirm password as \"([^\"]*)\"$")
	public void the_user_enter_confirm_password_as(String reenter) {
		switch (i) {
		case 1:
			driver.findElement(By.id("phdesktopbody_0_grs_account[password][confirm]")).sendKeys(reenter);
			break;
		case 2:
			driver.findElement(By.xpath("//*[@id=\"confirmPassword\"]")).sendKeys(reenter);
		}
	}

	@Then("^the user enter birthdate as \"([^\"]*)\"$")
	public void the_user_enter_birthdate_as(String birthdate) {

		int firstIndex = birthdate.indexOf('/');

		String month = birthdate.substring(0, firstIndex);
		String year = birthdate.substring(firstIndex + 1, birthdate.length());
		// System.out.println(month +"year:"+ year);

		switch (i) {
		case 1:
			WebElement Month = driver
					.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][month]\"]"));
			WebElement Year = driver.findElement(
					By.xpath("//*[@name='phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][year]']"));

			Select selectmonth = new Select(Month);
			selectmonth.selectByValue(month);
			Select selectyear = new Select(Year);
			selectyear.selectByValue(year);
			break;
		}

	}

	@Then("^the user enter zipcode as \"([^\"]*)\"$")
	public void the_user_enter_zipcode_as(String zipcode) {
		if (i == 1)
			driver.findElement(By.id("phdesktopbody_0_grs_account[addresses][0][postalarea]")).sendKeys(zipcode);
	}

	@Then("the user accepts terms and condition")
	public void the_user_accepts_terms_and_condition() throws InterruptedException {
		switch (i) {
		case 1:
			driver.findElement(By.id("phdesktopbody_0_ctl44")).click();
			break;
		case 2:
			((JavascriptExecutor) driver).executeScript("arguments[0].checked=true;",
					driver.findElement(By.id("OptInReceiveNewsLetterRadio2")));

			break;
		case 3:

			Thread.sleep(1000);
			WebElement element = driver.findElement(By.xpath("//*[@id=\"uniform-newsletter\"]/span"));
			((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);",
					element, "class", "checked");
			System.out.println("Captcha cannot be automated");
		}
	}

	@Then("the user creates profile successfully")
	public void the_user_creates_profile_successfully() throws InterruptedException {
		switch (i) {
		case 1:
			driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_submit\"]")).click();
			break;
		case 2:
			WebElement element = driver.findElement(By.xpath("//*[@id=\"continue\"]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			break;

		}
		System.out.println(driver.getTitle());

	}

	@When("the user navigates to login page")
	public void the_user_navigates_to_login_page() {
		switch (i) {
		case 1:
			driver.findElement(
					By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[1]")).click();
			break;
		case 2:
			new Actions(driver)
					.moveToElement(driver.findElement(By.xpath("//*[@id=\"nav\"]/div[2]/div[2]/div[2]/div/div[1]")))
					.perform();
			driver.findElement(By.xpath("//*[@id=\"nav\"]/div[2]/div[2]/div[2]/div/div[1]/div/nav/ul/li[1]/a")).click();
			break;
		case 3:
			driver.findElement(By.xpath("//*[@id=\"user_link\"]/li[1]/a")).click();

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"viewLoginForm\"]/a"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);
		}

	}

	@Then("^the user enter registed email as \"([^\"]*)\"$")
	public void the_user_enter_registed_email_as(String Email) {

		switch (i) {
		case 1:
			driver.findElement(By.id("phdesktopbody_0_username")).sendKeys(Email);
			break;
		case 2:
			driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(Email);
			break;
		case 3:
			driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(Email);
		}
	}

	@Then("^the user enter valid password as \"([^\"]*)\"$")
	public void the_user_enter_valid_password_as(String password) {
		switch (i) {
		case 1:
			driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_Container\"]/div[2]/input")).sendKeys(password);
			break;
		case 2:
			driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(password);
			break;
		case 3:
			driver.findElement(By.xpath("//*[@id=\"passwd\"]")).sendKeys(password);
		}

	}

	@Then("^the user logged in successfully$")
	public void the_user_logged_in_successfully() throws InterruptedException {

		
		if (i == 1)
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_Sign In\"]")));
		if (i == 2)
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",driver.findElement(By.xpath("//*[@id=\"login-submit\"]")));
			
		if (i == 3)
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",driver.findElement(By.xpath("//*[@id=\"SubmitLogin\"]")));
			
		System.out.println(driver.getTitle());
	}

	@Then("click on forget password button")
	public void click_on_forget_password_button() {
		WebElement key;
		switch (i) {
		case 1:
						
			key = driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_forgotpassword\"]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",key);
			break;
		case 2:
			key = driver.findElement(By.xpath("//*[@id=\"login-form\"]/div/div/div/button"));
			//key.click();
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",key);
			break;
		case 3:
			key = driver.findElement(By.xpath("//*[@id=\"login_form\"]/div[2]/p[1]"));
			key.click();
			//((JavascriptExecutor) driver).executeScript("arguments[0].click();",key);
		}
	}

	@Then("the user password is reset successfully")
	public void the_user_password_is_reset_successfully() {
		WebElement key;
		switch (i) {
		case 1:
			key = driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_Container\"]/div[2]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",key);
			break;
		case 2:
			key = driver.findElement(By.xpath("/html/body/div[3]/div/div/section[1]/form/input[4]"));
			key.click();
			//((JavascriptExecutor) driver).executeScript("arguments[0].click();",key);
			break;
		case 3:
			key = driver.findElement(By.xpath("//*[@id=\"form_forgotpassword\"]/p[2]/button"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",key);
		}
	}
	@Then("^the user enter forget email as \"([^\"]*)\"$")
	public <IWebElement> void the_user_enter_forget_email_as(String Email) {

		switch (i) {
		case 1:
			driver.findElement(By.id("phdesktopbody_0_username")).sendKeys(Email);
			break;
		case 2:
		
		driver.findElement(By.xpath("//*[@id=\"forgotten-password-email-field\"]")).sendKeys(Email);	
		break;
		case 3:
			driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(Email);
		}
	}

}
