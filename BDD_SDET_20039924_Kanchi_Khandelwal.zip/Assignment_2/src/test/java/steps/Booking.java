package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Epic;
import io.qameta.allure.Step;
import pages.Page;

public class Booking extends Page {
	public Page book = new Page(); 
@Epic("Boooking of tickets")
	@Before(value = "@Booking")
	public void OpenBrowser() {	
		start();
	}

	@After(value = "@Review")
	public void CloseBrowser() {
		//close();
	}
	@Step("Navigating to GoIbibo Website and choosing way as {0}")
	@Given("^Launch of GoIbibo Website and select the \"([^\"]*)\"$")
	public void user_select_travel_option_as(String way) {
		
		book.SelectWay(way);
	}
   
	@Step("Typing Booking Details : City : From {0} to {2} via {3} on {4} and {5} with no of travellers {6} and class{7}")
	@When("^user enter the booking details as \"([^\"]*)\" , \"([^\"]*)\" ,\"([^\"]*)\" , \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\" , \"([^\"]*)\"$")
	public void user_select_from_place_as(String departure, String arrival, String mid, String date, String retrn, String travel,
			String travellers) throws InterruptedException {
		book.SourceCity(departure);
		book.MidCity(mid);
		book.DestinationCity(arrival);
		book.Date(date, retrn);
		book.travellers(travellers, travel);
	}

	@Step("Clicking on Search button")
	@Then("the flights are search successfully")
	public void the_flights_are_search_successfully() {
	   
		book.search();
	}
	@Step("Selection of lowest Price flights and booking it")
	@When("User select the lowest price of flight and book")
	public void user_select_the_lowest_price_of_flight_and_book() {
		book.getFare();
		book.clickBook();
		System.out.println("clicking book");
	}
	@Step("Flight details are reviewed")
	@Then("The Flight selected details are reviewed.")
	public void the_Flight_selected_details_are_reviewed() throws InterruptedException {
		
		book.detailsReview();
		
	}

}
