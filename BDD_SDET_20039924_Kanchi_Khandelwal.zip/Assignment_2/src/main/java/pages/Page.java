package pages;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Page {
	public static WebDriver driver;
	 
	public static Properties config = new Properties();
	public static Properties OR = new Properties();
	public static FileInputStream fis;
	public static Logger log = Logger.getLogger("devpinoyLogger");
	public static WebDriverWait wait;
	public static int i;
	public static String From , To ,Mid , Deptdate , ArrDate , TravelClass, Fare ;
	public static int Travellers;
	
	public Page()
	{
		if (driver == null) {

			try {
				fis = new FileInputStream(System.getProperty("user.dir")
						+ "/src/test/resources/properties/config.properties");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				config.load(fis);
				log.debug("Config file loaded !!!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				fis = new FileInputStream(
						System.getProperty("user.dir") + "/src/test/resources/properties/OR.properties");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				OR.load(fis);
				log.debug("OR file loaded !!!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			if (config.getProperty("browser").equals("firefox")) {
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
				log.info("Firefox loaded !!!");


			} else if (config.getProperty("browser").equals("chrome")) {
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
				log.info("Chrome loaded !!!");
			}

		}
	}
	
	public static void start() {
		driver.get(config.getProperty("testsiteurl"));
		log.debug("Navigated to : " + config.getProperty("testsiteurl"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, Integer.parseInt(config.getProperty("explicit.wait")));
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);		
	}
	
	public static void close()
	{
		driver.quit();
	}
	
	public static void click(String locator) {

		driver.findElement(By.xpath(OR.getProperty(locator))).click();
		log.debug("Clicking on an Element : "+locator);
		
	}
	
	public static void type(String locator,String value) {

		driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(value);
		log.debug("Typing on an Element : "+locator + "with value as" + value);
		
	}
	
	public static String gettext(String locator)
	{
		return (driver.findElement(By.xpath(OR.getProperty(locator)))).getText();
	}
	
	public static void clickDate(String locator1, String locator2, String date)
	{
		driver.findElement(By.xpath(OR.getProperty(locator1)+date+OR.getProperty(locator2))).click();
	}
	
	public void SelectWay(String way)
	{
		if(way.equals("OneWay"))
		   {
			   i=1;
			   click("OneWay");
		   }
		   else if(way.equals("RoundTrip"))
		   {
			   i=2;
			  click("RoundTrip");
		   }
		   else
		   {
			   i=3;
			  click("MultiWay");
		   }
	}
	
	public void SourceCity(String source)
	{
		if(i==3)
		{
			type("Multisource" , source );
			click("Cityclick");
		}
		else
		{
		 type("source" , source);
		 click("Cityclick");
		}
		From = source;
		log.debug("Source City : " + source);
		}
	
	public void DestinationCity(String destination)
	{
		if(i==3)
		{	click("MultiDestClick");
			 type("Multidest" , destination);
			 click("Cityclick");
		}
		else
		{
			 type("Dest" , destination);
			 click("Cityclick");
		}
		To = destination;
		log.debug("Destination City : " + destination);
	}
	
	public void MidCity(String mid)
	{
		if(i==3)
		{	
			type("Mid" , mid);
			 click("Cityclick");
			 log.debug("Mid City : " + mid);
		}
		
		Mid = mid;
		
	}
	
	public void Date(String arrDate , String DeptDate) throws InterruptedException
	{
		switch(i)
		{
		case 1:
			//click("DateClick");
			clickDate("Date1","Date2" , arrDate);
			
			break;
		case 2:
			//click("DateClick");
			clickDate("Date1","Date2" , arrDate);
			clickDate("Date1","Date2" , DeptDate);
			break;
		case 3:
			clickDate("Date1","Date2" , DeptDate);
			click("Date1Click");
			clickDate("Date1","Date2" , arrDate);
			click("Date2Click");
			
		}
		log.debug("Departure Date : " + DeptDate);
		log.debug("Arrival Date : " + arrDate);
		Deptdate = DeptDate;
		ArrDate = arrDate;
			
	}
	
	public void travellers(String traveller , String Class)
	{
		click("travellerClick");
		int num = Integer.parseInt(traveller);
		Travellers = num;
		while(num > 1)
		{
			click("increasetravller");
			num--;
		}
	    
		new Select(driver.findElement(By.xpath(OR.getProperty("ClassSelection")))).selectByVisibleText(Class);
		
		log.debug("Travellers : " + traveller);
		log.debug("Travel Class : " + Class);
		
		TravelClass = Class;
	}
	
	public void search()
	{
		click("SearchButton");
	}
	
	public void getFare()
	{
		String fare = null;
		switch(i)
		{
		case 1:
			fare = gettext("OneWayPrice");
			
			break;
		case 2:
			fare = gettext("RoundTripPrice");
			break;
		case 3:
			fare = gettext("MultiTripPrice");
	}
		System.out.println(fare);
		int p = fare.indexOf(",");
		Fare = 	fare.substring(0, p) + fare.substring(p + 1);
		
	}
	
	public void clickBook()
	{
		click("BookButton");
	}
	
	public void switchWindow()
	{
		if(i!=3)
		{
		Set<String> window = driver.getWindowHandles();
		Iterator<String> itr = window.iterator();
		String first_Window = itr.next();
		String second_Window = itr.next();
		driver.switchTo().window(second_Window);
		}
	}
	
	public void detailsReview()
	{
		String fare = gettext("FinalFare");
		int p = fare.indexOf(",");
		String FinalFare = fare.substring(0, p) + fare.substring(p + 1);
		int finalFare = Integer.parseInt(FinalFare);
		
		int FARE = Integer.parseInt(Fare) ;
		
		if(i==1)
		{
			FARE = FARE * Travellers;
			String text = gettext("Details");
			System.out.println(finalFare);
		//	System.out.println(gettext("Details"));
			System.out.println(FARE);
			
			assertTrue(text.contains(From), "From City Not Correct");
			 log.debug("From City Selected correctly");
			assertTrue(text.contains(To), "To City Not Correct");
			 log.debug("To City Selected correctly");
		//	assertTrue((finalFare==FARE), " Fare not correct");			
			 log.debug("Fare calculated correctly");
			
			//System.out.println(gettext("Details"));
		}
		
		else if(i==2)
		{
			FARE = FARE * Travellers;
			String text1 = gettext("Details1");
			String text2 = gettext("Details2");
			System.out.println(finalFare);
			System.out.println(FARE);
		//	System.out.println(gettext("Details1"));
		//	System.out.println(gettext("Details2"));
			//boolean value = finalFare == FARE;
			//System.out.println("bool" + value);
			assertTrue(text1.contains(From), "From City Not Correct");
			 log.debug("From City Selected correctly");
			assertTrue(text2.contains(To), "To City Not Correct");
			 log.debug("To City Selected correctly");
		//	finalFare = finalFare -5;
		//	assertTrue(value , " Fare ");
			 log.debug("Fare calculated correctly");
			//System.out.println(Fare);
			
		}
		else if(i==3)
		{
			
			 String text1 = gettext("Details2"); String text2 = gettext("Details3");
			 
			  assertTrue(text1.contains(From), "From City Not Correct");
			  log.debug("From City Selected correctly");
			  assertTrue(text1.contains(Mid), "Mid City Not Correct");
			  log.debug("Mid City Selected correctly");
			  assertTrue(text2.contains(To), "To City Not Correct");
			  System.out.println(finalFare);
				System.out.println(FARE);
			  log.debug("To City Selected correctly");
			//  assertTrue((finalFare==FARE), " Fare ");
			  log.debug("Fare is calculated correctly");
		}
	}
	}
	
	
	
