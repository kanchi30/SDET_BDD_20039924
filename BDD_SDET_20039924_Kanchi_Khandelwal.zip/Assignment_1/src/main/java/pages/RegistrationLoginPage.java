package pages;


import static org.junit.jupiter.api.Assertions.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import basePage.Page;

public class RegistrationLoginPage extends Page {
	public static int i;
		
	public void selectURL(String URL) {
		driver.manage().window().maximize();
		driver.get(URL);
		if (URL.equals("https://www.gillette.co.in/en-in"))
			i = 1;
		else if (URL.equals("https://www.gillette.de/"))
			i = 2;
		else if (URL.equals("https://www.gillette.fr/"))
			i = 3;
	}

	public void navigatelogin() {
		switch (i) {
		case 1:
			click("Login_IN");
			break;
		case 2:
			movetoElement("Login1_DE");
			click("Login2_DE");
			break;
		case 3:
			click("Login1_FR");
			javaClick("Login2_FR");
		}
	}

	public void EmailPassword(String email, String password) {
		switch (i) {
		case 1:
			type("LoginEmail_IN", email);
			type("LoginPassword_IN", password);
			break;
		case 2:
			type("LoginEmail_DE", email);
			type("LoginPassword_DE", password);
			break;
		case 3:
			type("LoginEmail_FR", email);
			type("LoginPassword_FR", password);
		}

	}

	public void clickLogin() {
		switch (i) {
		case 1:
			javaClick("LoginButton_IN");
			break;
		case 2:
			javaClick("LoginButton_DE");
			break;
		case 3:
			javaClick("LoginButton_FR");
		}
	}
	public void clickLogOut() {
		switch (i) {
		case 1:
			javaClick("LogOut_IN");
			driver.findElement(By.id("phdesktopheader_0_phdesktopheadertop_2_anchrContinue")).click();
			break;
		case 2:
			javaClick("LogOut_DE");
			break;
		case 3:
			javaClick("LogOut_FR");
		}
	}
	
	public void navigatesRegistration() {
		switch (i) {
		case 1:
			click("Register1_IN");
			break;
		case 2:
			movetoElement("Register1_DE");
			click("Register2_DE");
			break;
		case 3:
			click("Register1_FR");
		}

	}

	public void fillName(String Fname, String Lname) {
		switch (i) {
		case 1:
			type("Fname_IN", Fname);
			type("Lname_IN", Lname);
			break;
		case 2:
			type("Fname_DE", Fname + " " + Lname);
			break;
		case 3:
			click("Fname1_FR");
			type("Fname2_FR", Fname);
			type("Lname_FR", Lname);
		}
	}

	public void EmailPassword(String Email, String Password, String confirmPassword) {
		switch (i) {
		case 1:
			type("Email_IN", Email);
			type("Password1_IN", Password);
			type("Password2_IN", confirmPassword);
			break;
		case 2:
			type("Email1_DE", Email);
			type("Email2_DE", Email);
			type("Password1_DE", Password);
			type("Password2_DE", confirmPassword);
			break;
		case 3:
			type("Email_FR", Email);
			type("Password1_FR", Password);
		}
	}

	public void birthDate(String birthDate, String zipcode) {
		int firstIndex = birthDate.indexOf('/');

		String month = birthDate.substring(0, firstIndex);
		String year = birthDate.substring(firstIndex + 1, birthDate.length());

		switch (i) {
		case 1:
			selectText("Month_IN", month);
			selectText("Year_IN", year);
			type("Zipcode_IN", zipcode);
			break;
		}
	}

	public void termsCondition() throws InterruptedException {
		switch (i) {
		case 1:
			click("Terms_IN");
			break;
		case 2:
			((JavascriptExecutor) driver).executeScript("arguments[0].checked=true;",
					driver.findElement(By.id("OptInReceiveNewsLetterRadio2")));

			break;
		case 3:

			Thread.sleep(1000);
			WebElement element = driver.findElement(By.xpath("//*[@id=\"uniform-newsletter\"]/span"));
			((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);",
					element, "class", "checked");
			log.debug("Cannot Automate CAPTHCHA");
		}

	}

	public void clickSubmit() {
		switch (i) {
		case 1:
			click("Submit_IN");

			// assertTrue();
			break;
		case 2:
			javaClick("Submit_DE");
			break;
		}
		driver.getTitle();

	}

	public void forgetPassword()

	{
		switch (i) {
		case 1:
			click("Forget_IN");
			break;
		case 2:
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(OR.getProperty("Forget_DE"))));
			javaClick("Forget_DE");
			break;
		case 3:
			javaClick("Forget_FR");

		}
	}

	public void resetEmail(String Email) throws InterruptedException {
		switch (i) {
		case 1:
			type("ResetEmail_IN", Email);
			break;
		case 2:
			driver.switchTo().activeElement();
			type("ResetEmail_DE", Email);
			Thread.sleep(1000);
			break;
		case 3:
			type("ResetEmail_FR", Email);
		}
	}

	public void resetButton() throws InterruptedException {
		switch (i) {
		case 1:
			javaClick("Reset_IN");
			assertTrue(driver.getTitle().equalsIgnoreCase("Reset my password") , "Reset is not successfull");			
			break;
		case 2:
			driver.switchTo().activeElement();
			javaClick("Reset_DE");
			Thread.sleep(1000);
			break;
		case 3:
			javaClick("Reset_FR");
			assertTrue(driver.getTitle().equalsIgnoreCase("Mot de passe oubli�") , "Reset is not successfull");
			
		}
	}
}