package steps;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.AfterEach;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import basePage.Page;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Step;
import pages.RegistrationLoginPage;
@Epic("Register,Login,ResetPassword for Gillete")
@Feature("Login , Register and Resert Password")
public class RegistrationSteps extends Page {
	public static WebDriver driver;
	public static JavascriptExecutor js = (JavascriptExecutor) driver;
	public static int i;
	RegistrationLoginPage page = new RegistrationLoginPage();
	
	@
	
	@BeforeClass()
	public void OpenBrowser() {
		start();
	}

	@AfterClass()
	public void CloseBrowser() {
		close();
	}
	@Step("Navigates to Website :: {0}")
	@Given("^User navigates to Gillete Website as \"([^\"]*)\"$")
	public void user_navigates_to_Gillete_Website_as(String URL) {
		
	  page.selectURL(URL);
	}

	@Step("Navigates to login Page")
	@When("the user navigates to login page")
	public void the_user_navigates_to_login_page() {
		page.navigatelogin();
	}
	@Step("Enter Email :: {0} and Password :: {1}")
	@When("^the user enter registed email as \"([^\"]*)\" and valid password as \"([^\"]*)\"$")
	public void the_user_enter_registed_email_as_and_valid_password_as(String Email, String password) {
	  
		page.EmailPassword(Email , password);
	}

	@Step("Login Successfull")
	@Then("the user logged in successfully")
	public void the_user_logged_in_successfully() {
	   page.clickLogin();
	   page.clickLogOut();
	}

	@When("the user navigates to registration page")
	public void the_user_navigates_to_registration_page() {
	   page.navigatesRegistration();
	}

	@When("the user enter name as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" & \"([^\"]*)\" , \"([^\"]*)\" & \"([^\"]*)\"$")
	public void the_user_enter_name_as(String Fname, String Lname, String Email, String password, String confirmpassword, String birthdate, String zipcode) {
	   page.fillName(Fname, Lname);
	   page.EmailPassword(Email, password, confirmpassword);
	   page.birthDate(birthdate,zipcode);
	   
	}

	@When("the user accepts terms and condition")
	public void the_user_accepts_terms_and_condition() throws InterruptedException {
	    page.termsCondition();
	}

	@Then("the user creates profile successfully")
	public void the_user_creates_profile_successfully() {
	    page.clickSubmit();
	}
	
	@Then("click on forget password button")
	public void click_on_forget_password_button() {
	 page.forgetPassword();  
	}
	
	@When("^click on forget password button & the user enter forget email as \"([^\"]*)\"$")
	public void click_on_forget_password_button_the_user_enter_forget_email_as(String Email) throws InterruptedException {
		page.forgetPassword();  
		page.resetEmail(Email);
	}

	@Then("the user password is reset successfully")
	public void the_user_password_is_reset_successfully() throws InterruptedException {
	 page.resetButton();
	 
	}
}
