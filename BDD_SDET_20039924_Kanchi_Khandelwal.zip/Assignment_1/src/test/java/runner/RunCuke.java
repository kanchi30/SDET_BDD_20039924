package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
//change tags:: Register :: Register
//              Login :: Login
//              ForgetPassword:: ForgetPassword
//              ResetPassword :: Reset
@CucumberOptions(stepNotifications = true,
  				 features = "src/test/java/features", 
  				 glue = "steps", monochrome = true, 
  				 tags = {"@Login"} ,
  				 plugin={"html:target/cucumber-html-report","json:target/cucumber-reports/cucumber.json","junit:target/cucumber-reports/cucumber.xml","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"})
@RunWith(Cucumber.class)
public class RunCuke {

}
